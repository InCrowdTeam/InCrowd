/* ============================================================
   InCrowd — User / Ente profile
   ============================================================ */
const { useState: useStateProfile } = React;

function ProfileScreen({ uid, variant, hypeState, onHype, onOpen, isMe, mobile }) {
  const u = USERS[uid] || USERS.anna;
  const [tab, setTab] = useStateProfile("proposte");
  const mine = PROPOSALS.filter(p => p.author === u.id && p.status === "approvata");
  const hyped = PROPOSALS.filter(p => (hypeState[p.id]?.active) && p.status==="approvata");
  const following = [USERS.giacomo, USERS.corpo].filter(Boolean);

  const stats = [
    { n: mine.length, l:"Proposte" },
    { n: hyped.length || 1, l:"Hyped" },
    { n: 2, l:"Follower" },
    { n: u.id==="anna"?0:1, l:"Seguiti" },
  ];

  const shown = tab==="proposte" ? mine : tab==="hyped" ? (hyped.length?hyped:mine.slice(0,1)) : [];
  const getCount = (p) => hypeState[p.id]?.count ?? p.hype;

  return (
    <div style={{ maxWidth:"var(--maxw)", margin:"0 auto", padding:"clamp(16px,3vw,28px) clamp(14px,4vw,28px) 80px", display:"flex", flexDirection:"column", gap:"var(--s-5)" }}>
      {/* header */}
      <Card pad="0" className="fade-in" style={{ overflow:"hidden" }}>
        <div style={{ height: mobile?80:120, background:`linear-gradient(115deg, ${u.tint}, color-mix(in srgb, ${u.tint} 40%, var(--brand)))`, position:"relative" }}>
          <div style={{ position:"absolute", right:-20, top:-30, width:160, height:160, borderRadius:"50%", background:"rgba(255,255,255,.12)" }} />
        </div>
        <div style={{ padding:"0 clamp(18px,3vw,28px) 24px", marginTop: mobile?-36:-46 }}>
          <div style={{ display:"flex", alignItems:"flex-end", gap:18, flexWrap:"wrap" }}>
            <div style={{ width: mobile?80:100, height: mobile?80:100, borderRadius:"50%", background:u.tint, color:"#fff",
              display:"grid", placeItems:"center", fontFamily:"var(--font-display)", fontWeight:800, fontSize:mobile?32:40,
              border:"5px solid var(--surface)", boxShadow:"var(--shadow-md)" }}>{u.initials}</div>
            <div style={{ flex:1, minWidth:200, paddingBottom:6 }}>
              <div style={{ display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
                <h1 style={{ fontSize:"clamp(24px,3.5vw,32px)", fontWeight:800 }}>{u.name}</h1>
                <RoleBadge type={u.type} />
              </div>
            </div>
            {isMe
              ? <Btn variant="ghost" icon="edit">Modifica profilo</Btn>
              : <Btn icon="plus">Segui</Btn>}
          </div>

          {isMe && (
            <div style={{ display:"flex", alignItems:"center", gap:9, marginTop:16, padding:"11px 15px", borderRadius:"var(--r-md)",
              background:"var(--brand-soft)", color:"var(--brand-700)", fontSize:13.5, fontWeight:600 }}>
              <Icon name="eye" size={17} />Questo è il tuo profilo pubblico — è così che ti vede la community.
            </div>
          )}
          <p style={{ marginTop:14, fontSize:15.5, color:"var(--ink-2)", lineHeight:1.5, maxWidth:560 }}>{u.bio || "Nessuna bio."}</p>

          <div style={{ display:"flex", gap: mobile?20:34, marginTop:20 }}>
            {stats.map(s => (
              <div key={s.l}>
                <div style={{ fontFamily:"var(--font-display)", fontWeight:800, fontSize:26, color:"var(--brand)" }}>{s.n}</div>
                <div style={{ fontSize:12.5, color:"var(--ink-3)", fontWeight:600 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <div><PillTabs full active={tab} onChange={setTab} tabs={[
        {id:"proposte",label:"Proposte",icon:"sparkle"},
        {id:"hyped",label:"Hyped",icon:"bolt"},
        {id:"seguiti",label:"Seguiti",icon:"users"},
      ]} /></div>

      {tab === "seguiti" ? (
        <div style={{ display:"grid", gap:14, gridTemplateColumns: mobile?"1fr":"repeat(auto-fill,minmax(250px,1fr))" }}>
          {following.map(f => (
            <Card key={f.id} hover onClick={()=>onOpen("profile",f.id)} pad="16px">
              <div style={{ display:"flex", gap:12, alignItems:"center" }}>
                <Avatar user={f} size={46} />
                <div style={{ minWidth:0 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:7 }}>
                    <span style={{ fontWeight:700, fontSize:15, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{f.name}</span>
                  </div>
                  <div style={{ fontSize:12.5, color:"var(--ink-3)", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{f.bio}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : shown.length === 0 ? (
        <div style={{ textAlign:"center", padding:"60px", color:"var(--ink-3)" }}>
          <Icon name="sparkle" size={32} style={{ opacity:.4, margin:"0 auto 10px" }} />
          <div style={{ fontWeight:700, color:"var(--ink-2)" }}>Niente da mostrare qui</div>
        </div>
      ) : (
        <div style={{ display:"grid", gap: mobile?16:"var(--s-5)", gridTemplateColumns: mobile?"1fr":"repeat(auto-fill,minmax(258px,1fr))" }}>
          {shown.map(p => (
            <ProposalCard key={p.id} p={p} variant={variant} hyped={!!hypeState[p.id]?.active} count={getCount(p)}
              onHype={()=>onHype(p.id)} onOpen={(id)=>onOpen("detail",id)} mobile={mobile} />
          ))}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { ProfileScreen });

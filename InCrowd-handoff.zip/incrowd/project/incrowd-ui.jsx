/* ============================================================
   InCrowd — shared UI primitives
   ============================================================ */
const { useState: useStateUI } = React;

/* ---- Button ---- */
function Btn({ children, variant = "primary", size = "md", icon, iconRight, full, onClick, type, style = {}, disabled }) {
  const sz = { sm:{p:"8px 14px",fs:13.5}, md:{p:"11px 18px",fs:14.5}, lg:{p:"14px 24px",fs:16} }[size];
  const variants = {
    primary: { background:"var(--brand)", color:"#fff", border:"1px solid transparent", boxShadow:"0 4px 14px rgba(255,77,94,.32)" },
    dark:    { background:"var(--ink)", color:"var(--ink-inv)", border:"1px solid transparent" },
    ghost:   { background:"transparent", color:"var(--ink-2)", border:"1px solid var(--border)" },
    soft:    { background:"var(--brand-soft)", color:"var(--brand-700)", border:"1px solid transparent" },
    success: { background:"var(--cat-sport-soft)", color:"var(--cat-sport)", border:"1px solid transparent" },
    danger:  { background:"var(--brand-soft)", color:"var(--brand-700)", border:"1px solid transparent" },
  };
  return (
    <button type={type||"button"} onClick={onClick} disabled={disabled} className="ic-btn" data-variant={variant}
      style={{ display:"inline-flex", alignItems:"center", justifyContent:"center", gap:8,
        padding:sz.p, fontSize:sz.fs, fontWeight:700, borderRadius:"var(--r-pill)",
        width:full?"100%":"auto", opacity:disabled?.5:1, cursor:disabled?"not-allowed":"pointer",
        transition:"all .18s var(--ease)", ...variants[variant], ...style }}>
      {icon && <Icon name={icon} size={size==="lg"?20:17} />}
      {children}
      {iconRight && <Icon name={iconRight} size={size==="lg"?20:17} />}
    </button>
  );
}

/* ---- Badge ---- */
function Badge({ children, color = "var(--ink-2)", bg = "var(--surface-3)", icon, style = {} }) {
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"4px 10px",
      borderRadius:"var(--r-pill)", fontSize:11.5, fontWeight:700, letterSpacing:".03em",
      textTransform:"uppercase", color, background:bg, ...style }}>
      {icon && <Icon name={icon} size={12} stroke={2.2} />}
      {children}
    </span>
  );
}

function RoleBadge({ type }) {
  if (type === "ente") return <Badge color="var(--cat-cultura)" bg="var(--cat-cultura-soft)" icon="building">Ente</Badge>;
  return <Badge color="var(--cat-workshop)" bg="var(--cat-workshop-soft)" icon="user">Utente</Badge>;
}

/* ---- Avatar ---- */
function Avatar({ user, size = 40, ring = false }) {
  const u = typeof user === "string" ? USERS[user] : user;
  if (!u) return null;
  return (
    <div style={{ width:size, height:size, borderRadius:"50%", flexShrink:0,
      background: u.tint || "var(--brand)", color:"#fff",
      display:"grid", placeItems:"center", fontWeight:800, fontFamily:"var(--font-display)",
      fontSize:size*0.38, letterSpacing:"-.02em",
      boxShadow: ring ? "0 0 0 3px var(--surface), 0 0 0 5px var(--brand)" : "var(--shadow-sm)" }}>
      {u.initials}
    </div>
  );
}

/* ---- Category tag ---- */
function CatTag({ cat, solid = false, size = "md" }) {
  const c = CATEGORIES[cat]; if (!c) return null;
  const sm = size === "sm";
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:6,
      padding: sm?"4px 9px":"6px 12px", borderRadius:"var(--r-pill)",
      fontSize: sm?11.5:12.5, fontWeight:700, lineHeight:1,
      color: solid ? "#fff" : c.color,
      background: solid ? c.color : c.soft }}>
      <Icon name={c.icon} size={sm?12:14} stroke={2.1} />
      {c.label}
    </span>
  );
}

/* ---- Image placeholder (category-tinted, honest) ---- */
function ImgPlaceholder({ cat, label, ratio = "16/10", radius = "var(--r-md)", style = {} }) {
  const c = CATEGORIES[cat];
  const tint = c ? c.color : "var(--brand)";
  return (
    <div style={{ position:"relative", aspectRatio:ratio, borderRadius:radius, overflow:"hidden",
      background:`linear-gradient(135deg, color-mix(in srgb, ${tint} 22%, var(--img-a)), var(--img-b))`,
      display:"grid", placeItems:"center", ...style }}>
      <svg width="100%" height="100%" style={{ position:"absolute", inset:0, opacity:.5 }} aria-hidden="true">
        <defs>
          <pattern id={`stripe-${label}`} width="22" height="22" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <rect width="22" height="22" fill="transparent" />
            <line x1="0" y1="0" x2="0" y2="22" stroke={tint} strokeWidth="1" opacity="0.18" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#stripe-${label})`} />
      </svg>
      {c && <Icon name={c.icon} size={34} stroke={1.6} style={{ color:tint, opacity:.6, position:"relative" }} />}
      <span className="mono" style={{ position:"absolute", bottom:9, left:11, fontSize:10.5,
        color:"var(--ink-3)", background:"color-mix(in srgb, var(--surface) 70%, transparent)",
        padding:"2px 7px", borderRadius:6, letterSpacing:"-.02em" }}>foto · {label}</span>
    </div>
  );
}

/* ---- Card shell ---- */
function Card({ children, pad = "var(--s-5)", style = {}, onClick, hover = false, className = "" }) {
  return (
    <div onClick={onClick} className={`ic-card ${hover?"ic-card-hover":""} ${className}`}
      style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:"var(--r-lg)",
        padding:pad, boxShadow:"var(--shadow-sm)", transition:"all .22s var(--ease)",
        cursor:onClick?"pointer":"default", ...style }}>
      {children}
    </div>
  );
}

/* ---- Section heading ---- */
function SectionTitle({ children, sub, action }) {
  return (
    <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", marginBottom:"var(--s-4)", gap:16, flexWrap:"wrap" }}>
      <div>
        <h2 style={{ fontSize:"clamp(20px,3vw,26px)", fontWeight:700, color:"var(--ink)" }}>{children}</h2>
        {sub && <p style={{ color:"var(--ink-3)", fontSize:14.5, marginTop:5 }}>{sub}</p>}
      </div>
      {action}
    </div>
  );
}

/* ---- Pill tabs ---- */
function PillTabs({ tabs, active, onChange, full = false }) {
  return (
    <div style={{ display:"inline-flex", background:"var(--surface-3)", borderRadius:"var(--r-pill)",
      padding:4, gap:3, width:full?"100%":"auto" }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => onChange(t.id)}
          style={{ flex:full?1:"none", display:"inline-flex", alignItems:"center", justifyContent:"center", gap:7,
            padding:"9px 18px", borderRadius:"var(--r-pill)", fontSize:14, fontWeight:700,
            color: active===t.id ? "#fff" : "var(--ink-2)",
            background: active===t.id ? "var(--brand)" : "transparent",
            boxShadow: active===t.id ? "0 3px 10px rgba(255,77,94,.3)" : "none",
            transition:"all .2s var(--ease)" }}>
          {t.icon && <Icon name={t.icon} size={16} />}
          {t.label}
        </button>
      ))}
    </div>
  );
}

const UI_CSS = `
.ic-btn:hover { transform: translateY(-1px); filter: brightness(1.04); }
.ic-btn:active { transform: translateY(0); }
.ic-card-hover:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); border-color: var(--border-strong); }
.ic-input { width:100%; padding:12px 15px; border-radius:var(--r-sm); border:1.5px solid var(--border);
  background:var(--surface-2); color:var(--ink); font-size:14.5px; transition:all .18s var(--ease); }
.ic-input::placeholder { color:var(--ink-3); }
.ic-input:focus { outline:none; border-color:var(--brand); background:var(--surface);
  box-shadow:0 0 0 4px var(--brand-soft); }
.ic-label { display:flex; align-items:center; gap:7px; font-size:13px; font-weight:700; color:var(--ink-2); margin-bottom:8px; }
`;
(function(){ const s=document.createElement("style"); s.textContent=UI_CSS; document.head.appendChild(s); })();

Object.assign(window, { Btn, Badge, RoleBadge, Avatar, CatTag, ImgPlaceholder, Card, SectionTitle, PillTabs });

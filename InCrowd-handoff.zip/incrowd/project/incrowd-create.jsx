/* ============================================================
   InCrowd — Create proposal wizard (3 steps)
   ============================================================ */
const { useState: useStateCreate } = React;

function Stepper({ step, steps }) {
  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:0, marginBottom:30, flexWrap:"wrap" }}>
      {steps.map((s,i) => {
        const n = i+1, done = n < step, on = n === step;
        return (
          <React.Fragment key={s.id}>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:7 }}>
              <div style={{ width:42, height:42, borderRadius:"50%", display:"grid", placeItems:"center",
                fontWeight:800, fontSize:16, fontFamily:"var(--font-display)", transition:"all .25s var(--ease-back)",
                background: on||done?"var(--brand)":"var(--surface-3)", color: on||done?"#fff":"var(--ink-3)",
                boxShadow: on?"0 5px 16px rgba(255,77,94,.4)":"none" }}>
                {done ? <Icon name="check" size={20} stroke={2.5} /> : n}
              </div>
              <div style={{ fontSize:12.5, fontWeight:700, color: on?"var(--brand-700)":done?"var(--ink-2)":"var(--ink-3)" }}>{s.label}</div>
            </div>
            {i < steps.length-1 && <div style={{ width:"clamp(24px,8vw,90px)", height:3, borderRadius:2, margin:"0 6px 22px",
              background: done?"var(--brand)":"var(--border)", transition:"background .3s var(--ease)" }} />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function CreateScreen({ mobile, onDone }) {
  const [step, setStep] = useStateCreate(1);
  const [form, setForm] = useStateCreate({ title:"", cat:"", desc:"", place:"", address:"", date:"" });
  const set = (k,v) => setForm(f => ({...f, [k]:v}));
  const steps = [ {id:1,label:"Info base"}, {id:2,label:"Foto"}, {id:3,label:"Luogo & Data"} ];

  const canNext = step===1 ? (form.title && form.cat && form.desc) : step===3 ? (form.place && form.date) : true;

  return (
    <div style={{ maxWidth:760, margin:"0 auto", padding:"clamp(20px,3vw,40px) clamp(14px,4vw,24px) 80px" }}>
      <div style={{ textAlign:"center", marginBottom:28 }}>
        <h1 style={{ fontSize:"clamp(28px,4vw,38px)", fontWeight:800 }}>Crea la tua Proposta</h1>
        <p style={{ color:"var(--ink-3)", marginTop:8, fontSize:16 }}>Condividi la tua idea con la community</p>
      </div>

      <Stepper step={step} steps={steps} />

      <Card pad="clamp(20px,3vw,30px)" className="fade-in" style={{ minHeight:320 }}>
        {step === 1 && (
          <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
            <h2 style={{ fontSize:20, fontWeight:700, textAlign:"center" }}>Informazioni base</h2>
            <div style={{ display:"grid", gap:18, gridTemplateColumns: mobile?"1fr":"1fr 1fr" }}>
              <div>
                <label className="ic-label"><Icon name="target" size={15} style={{color:"var(--brand)"}}/>Titolo della proposta *</label>
                <input className="ic-input" value={form.title} onChange={e=>set("title",e.target.value)} placeholder="Es: Workshop di fotografia urbana" />
              </div>
              <div>
                <label className="ic-label"><Icon name="edit" size={15} style={{color:"var(--brand)"}}/>Categoria *</label>
                <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                  {CAT_ORDER.map(c => {
                    const on = form.cat===c, cc=CATEGORIES[c];
                    return <button key={c} onClick={()=>set("cat",c)} type="button"
                      style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"8px 13px", borderRadius:"var(--r-pill)",
                        fontSize:13, fontWeight:700, border:`1px solid ${on?"transparent":"var(--border)"}`,
                        color:on?"#fff":cc.color, background:on?cc.color:"var(--surface-2)", transition:"all .15s var(--ease)" }}>
                      <Icon name={cc.icon} size={14} stroke={2}/>{cc.label}</button>;
                  })}
                </div>
              </div>
            </div>
            <div>
              <label className="ic-label"><Icon name="comment" size={15} style={{color:"var(--brand)"}}/>Descrizione dettagliata *</label>
              <textarea className="ic-input" value={form.desc} onChange={e=>set("desc",e.target.value)} rows={4}
                placeholder="Descrivi la tua proposta in dettaglio…" style={{ resize:"vertical", minHeight:110 }} />
            </div>
          </div>
        )}

        {step === 2 && (
          <div style={{ display:"flex", flexDirection:"column", gap:18 }}>
            <h2 style={{ fontSize:20, fontWeight:700, textAlign:"center" }}>Foto di copertina</h2>
            <p style={{ textAlign:"center", color:"var(--ink-3)", fontSize:14.5, marginTop:-8 }}>Una bella immagine attira più hype ⚡</p>
            <label style={{ border:"2px dashed var(--border-strong)", borderRadius:"var(--r-lg)", padding:"44px 20px",
              textAlign:"center", cursor:"pointer", background:"var(--surface-2)", display:"block", transition:"all .18s var(--ease)" }}
              className="ic-card-hover">
              <div style={{ width:64, height:64, borderRadius:"50%", background:form.cat?CATEGORIES[form.cat].soft:"var(--brand-soft)", display:"grid", placeItems:"center", margin:"0 auto 14px" }}>
                <Icon name="camera" size={28} style={{ color:form.cat?CATEGORIES[form.cat].color:"var(--brand)" }} />
              </div>
              <div style={{ fontWeight:700, fontSize:16 }}>Trascina un'immagine o clicca per caricare</div>
              <div style={{ fontSize:13, color:"var(--ink-3)", marginTop:5 }}>JPG o PNG · max 5MB</div>
            </label>
            {form.cat && <ImgPlaceholder cat={form.cat} label="anteprima" ratio="21/9" />}
          </div>
        )}

        {step === 3 && (
          <div style={{ display:"flex", flexDirection:"column", gap:18 }}>
            <h2 style={{ fontSize:20, fontWeight:700, textAlign:"center" }}>Luogo & Data</h2>
            <div style={{ display:"grid", gap:18, gridTemplateColumns: mobile?"1fr":"1fr 1fr" }}>
              <div>
                <label className="ic-label"><Icon name="pin" size={15} style={{color:"var(--brand)"}}/>Luogo *</label>
                <input className="ic-input" value={form.place} onChange={e=>set("place",e.target.value)} placeholder="Es: Parco delle Albere, Trento" />
              </div>
              <div>
                <label className="ic-label"><Icon name="building" size={15} style={{color:"var(--brand)"}}/>Indirizzo</label>
                <input className="ic-input" value={form.address} onChange={e=>set("address",e.target.value)} placeholder="Via, numero civico" />
              </div>
              <div>
                <label className="ic-label"><Icon name="calendar" size={15} style={{color:"var(--brand)"}}/>Data ipotetica *</label>
                <input className="ic-input" type="date" value={form.date} onChange={e=>set("date",e.target.value)} />
              </div>
            </div>
            <div style={{ marginTop:6, padding:"14px 16px", borderRadius:"var(--r-md)", background:"var(--cat-workshop-soft)",
              color:"var(--cat-workshop)", fontSize:13.5, fontWeight:600, display:"flex", gap:9, alignItems:"flex-start" }}>
              <Icon name="shield" size={18} style={{ flexShrink:0, marginTop:1 }} />
              La proposta verrà inviata in moderazione. Un operatore la approverà prima della pubblicazione.
            </div>
          </div>
        )}

        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:28, paddingTop:20, borderTop:"1px solid var(--border)" }}>
          {step > 1 ? <Btn variant="ghost" icon="arrowleft" onClick={()=>setStep(s=>s-1)}>Indietro</Btn> : <span/>}
          {step < 3
            ? <Btn iconRight="arrowright" disabled={!canNext} onClick={()=>setStep(s=>s+1)}>Avanti</Btn>
            : <Btn icon="check" disabled={!canNext} onClick={onDone}>Invia proposta</Btn>}
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { CreateScreen });

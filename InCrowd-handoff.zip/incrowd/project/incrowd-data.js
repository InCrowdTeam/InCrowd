/* ============================================================
   InCrowd — domain data (mock)
   ============================================================ */

const CATEGORIES = {
  cultura:            { label: "Cultura",            color: "var(--cat-cultura)",    soft: "var(--cat-cultura-soft)",    icon: "masks" },
  concerti:           { label: "Concerti",           color: "var(--cat-concerti)",   soft: "var(--cat-concerti-soft)",   icon: "music" },
  mostreInstallazioni:{ label: "Mostre",             color: "var(--cat-mostre)",     soft: "var(--cat-mostre-soft)",     icon: "image" },
  sport:              { label: "Sport",              color: "var(--cat-sport)",      soft: "var(--cat-sport-soft)",      icon: "activity" },
  workshopCorsi:      { label: "Workshop e corsi",   color: "var(--cat-workshop)",   soft: "var(--cat-workshop-soft)",   icon: "tool" },
  conferenze:         { label: "Conferenze",         color: "var(--cat-conferenze)", soft: "var(--cat-conferenze-soft)", icon: "mic" },
};
const CAT_ORDER = ["cultura","concerti","mostreInstallazioni","sport","workshopCorsi","conferenze"];

/* People & organisations */
const USERS = {
  anna:    { id:"anna",    name:"Anna Rossi",            type:"utente", email:"utente@incrowd.com",            bio:"Ciao! Benvenuti sul mio profilo!",                                       reg:"16/08/2025", initials:"AR", tint:"var(--cat-concerti)" },
  giacomo: { id:"giacomo", name:"Giacomo Berti",         type:"utente", email:"bertii.giacomo@gmail.com",       bio:"Ciao! Sono Giacomo, studente di Informatica all'Università di Trento.",   reg:"16/07/2025", initials:"GB", tint:"var(--cat-workshop)" },
  giorgia: { id:"giorgia", name:"Giorgia Fontanini",     type:"utente", email:"giorgiafontanini13@gmail.com",   bio:"amo InCrowd tanto quanto ho pianto sul suo codice",                       reg:"19/07/2025", initials:"GF", tint:"var(--cat-cultura)" },
  danilo:  { id:"danilo",  name:"Danilo Mormino",        type:"utente", email:"danilo.23morm@gmail.com",        bio:"",                                                                        reg:"07/10/2025", initials:"DM", tint:"var(--brand)" },
  franci:  { id:"franci",  name:"fra nci",               type:"utente", email:"lurgiofra@gmail.com",            bio:"Sono Frella, nel tempo libero mi piace giocare a basket e fotografare.",  reg:"27/07/2025", initials:"FN", tint:"var(--cat-sport)" },
  francesco:{id:"francesco",name:"Francesco Annunziata", type:"utente", email:"francescoannu04@gmail.com",      bio:"Studente universitario a Trento. Vivo a Brescia.",                        reg:"05/08/2025", initials:"FA", tint:"var(--cat-conferenze)" },
  corpo:   { id:"corpo",   name:"Corpo Strumentale \"Città di Trento\"", type:"ente", email:"ente@incrowd.com", bio:"Siamo il Corpo Strumentale della Città di Trento, banda cittadina dal 1926.", reg:"16/08/2025", initials:"CT", tint:"#1b2a4a" },
  unitin:  { id:"unitin",  name:"UNITiN",                type:"ente",   email:"unitin@incrowd.com",             bio:"Siamo i tuoi rappresentanti a UniTrento",                                 reg:"22/08/2025", initials:"UT", tint:"var(--cat-conferenze)" },
};

/* Proposals */
const PROPOSALS = [
  { id:"p1", title:"Invitare Starting Finance a Trento", cat:"workshopCorsi", author:"giacomo",
    short:"Propongo di invitare Starting Finance a Trento, per un workshop sull'educazione finanziaria!",
    body:"Propongo di invitare Starting Finance a Trento, per un workshop sull'educazione finanziaria! Starting Finance è un progetto di divulgazione creato da dei ragazzi che ha l'obiettivo di rendere l'economia accessibile a tutti, con un linguaggio semplice e diretto.",
    place:"Trento", address:"Trento, n. 1", cap:"38121", date:"mercoledì 1 aprile 2026", dateShort:"01/04/2026", created:"18 ago 2025",
    hype:5, supporters:["unitin"], status:"approvata" },
  { id:"p2", title:"Corso di cucina molecolare", cat:"workshopCorsi", author:"giorgia",
    short:"Un percorso unico per scoprire come trasformare gli ingredienti in esperienze sorprendenti.",
    body:"Un percorso unico per scoprire come trasformare gli ingredienti in esperienze sorprendenti, fra sferificazioni, gel e schiume. Tre serate guidate da uno chef del territorio.",
    place:"Trento", address:"Via del Suffragio 12", cap:"38122", date:"sabato 11 ottobre 2025", dateShort:"11/10/2025", created:"02 set 2025",
    hype:2, supporters:[], status:"approvata" },
  { id:"p3", title:"Concerto Alle Albere", cat:"concerti", author:"corpo",
    short:"Buongiorno! Siamo il Corpo Strumentale della Città di Trento. Cerchiamo il supporto della community per un concerto al Parco.",
    body:"Buongiorno! Siamo il Corpo Strumentale della Città di Trento. Cerchiamo il supporto della community per organizzare un concerto all'aperto nella splendida cornice del Parco delle Albere. Musica per tutte le età.",
    place:"Parco delle Albere", address:"Via Roberto da Sanseverino", cap:"38122", date:"domenica 7 settembre 2025", dateShort:"07/09/2025", created:"16 ago 2025",
    hype:4, supporters:["unitin"], status:"approvata" },
  { id:"p4", title:"Siamo figli delle stelle", cat:"cultura", author:"anna",
    short:"Un tour nel bosco con una guida, che racconti delle stelle e dei pianeti!",
    body:"Un tour nel bosco con una guida, che racconti delle stelle e dei pianeti! Una serata di astronomia sul Monte Bondone, lontano dalle luci della città, con telescopi e racconti del cielo.",
    place:"Monte Bondone", address:"Località Vason", cap:"38123", date:"venerdì 18 agosto 2025", dateShort:"18/08/2025", created:"18 ago 2025",
    hype:5, supporters:[], status:"approvata" },
  { id:"p5", title:"Festival culinario asiatico", cat:"cultura", author:"anna",
    short:"Invitare il tour asiatico culinario che sta facendo il giro dell'Italia. Sarebbero una serie di food truck.",
    body:"Invitare il tour asiatico culinario che sta facendo il giro dell'Italia. Sarebbero una serie di food truck con cucina thailandese, giapponese e coreana, in Piazza Fiera per un weekend.",
    place:"Piazza Fiera", address:"Piazza Fiera", cap:"38122", date:"sabato 18 ottobre 2025", dateShort:"18/10/2025", created:"18 ago 2025",
    hype:2, supporters:[], status:"approvata" },
  { id:"p6", title:"Cinema all'aperto", cat:"cultura", author:"franci",
    short:"Partecipa anche tu alla visione del famosissimo film 'Inside Out'!",
    body:"Partecipa anche tu alla visione del famosissimo film 'Inside Out 2' sotto le stelle! Proiezione gratuita all'Oratorio, portate la coperta.",
    place:"Brescia", address:"Via Matteotti 61, Castenedolo", cap:"25014", date:"sabato 19 luglio 2025", dateShort:"19/07/2025", created:"01 lug 2025",
    hype:4, supporters:[], status:"approvata" },
  { id:"p7", title:"Meet & Greet con i Mates e FaviJ", cat:"conferenze", author:"francesco",
    short:"Vorrei incontrare i miei idoli di quando ero piccola.",
    body:"Vorrei incontrare i miei idoli di quando ero piccola. Un pomeriggio di incontro con i content creator, foto, autografi e tante domande dal pubblico.",
    place:"Castellammare di Stabia", address:"Lungomare", cap:"80053", date:"domenica 14 settembre 2025", dateShort:"14/09/2025", created:"20 ago 2025",
    hype:5, supporters:[], status:"approvata" },
  { id:"p8", title:"Concerto dei Me Contro Te", cat:"concerti", author:"giorgia",
    short:"Concerto bellissimo in compagnia dei tuoi due content creator preferiti, sei pronto?",
    body:"Concerto bellissimo in compagnia dei tuoi due content creator preferiti, sei pronto? Uno show pieno di musica, balli e sorprese per i più piccoli e le famiglie.",
    place:"Trento", address:"PalaTrento", cap:"38121", date:"sabato 13 dicembre 2025", dateShort:"13/12/2025", created:"22 ago 2025",
    hype:9, supporters:["unitin","corpo"], status:"approvata" },
  /* pending moderation */
  { id:"p9", title:"Workshop di fotografia urbana", cat:"workshopCorsi", author:"francesco",
    short:"Il workshop weekend Street Photography affronta la fotografia urbana e di strada.",
    body:"Il workshop weekend Street Photography affronta la fotografia urbana e la fotografia di strada, con l'intenzione di far emergere la sensibilità e le abilità tecniche per realizzare immagini accattivanti che testimonino il nostro tempo.",
    place:"Trento", address:"Centro storico", cap:"38122", date:"venerdì 22 agosto 2025", dateShort:"22/08/2025", created:"10 ago 2025",
    hype:0, supporters:[], status:"in_approvazione" },
];

const COMMENTS = {
  p1: [
    { id:"c1", user:"giorgia", text:"Idea fantastica! L'educazione finanziaria a scuola manca totalmente.", time:"2 giorni fa", replies:[
      { id:"c1r1", user:"giacomo", text:"Grazie Giorgia! Speriamo di raccogliere abbastanza hype 🙌", time:"1 giorno fa" },
    ]},
    { id:"c2", user:"francesco", text:"Mi iscriverei subito. Trento ha bisogno di più eventi così.", time:"6 ore fa", replies:[] },
  ],
  p8: [
    { id:"c3", user:"anna", text:"I miei nipoti impazzirebbero 😍", time:"3 giorni fa", replies:[] },
  ],
};

const OPERATOR = { name:"Operatore Test", email:"operatore@incrowd.com", initials:"OT" };
const ADMIN = { name:"Admin Sistema", email:"admin@incrowd.com", initials:"AS" };

const STATS = { inAttesa:1, approvate:8, rifiutate:1, utenti:8, enti:2, commenti:13 };

Object.assign(window, { CATEGORIES, CAT_ORDER, USERS, PROPOSALS, COMMENTS, OPERATOR, ADMIN, STATS });

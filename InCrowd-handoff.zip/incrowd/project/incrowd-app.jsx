/* ============================================================
   InCrowd — app root: chrome, routing, state
   ============================================================ */
const { useState, useEffect, useCallback } = React;

const STYLE_NAMES = { A:"Editoriale", B:"Vivace", C:"Magazine" };

function Toast({ msg }) {
  if (!msg) return null;
  return (
    <div className="fade-in" style={{ position:"fixed", bottom:26, left:"50%", transform:"translateX(-50%)", zIndex:200,
      background:"var(--ink)", color:"var(--ink-inv)", padding:"13px 22px", borderRadius:"var(--r-pill)",
      boxShadow:"var(--shadow-lg)", display:"flex", alignItems:"center", gap:10, fontWeight:700, fontSize:14.5, maxWidth:"90vw" }}>
      <Icon name="check" size={18} stroke={2.5} style={{ color:"var(--cat-sport)" }} />{msg}
    </div>
  );
}

function App() {
  const [theme, setTheme]   = useState("light");
  const [device, setDevice] = useState("desktop");
  const [variant, setVariant] = useState("A");
  const [role, setRole]     = useState("utente");
  const [route, setRoute]   = useState({ screen:"feed", param:null });
  const [hypeState, setHypeState] = useState({});
  const [toast, setToast]   = useState("");

  useEffect(() => { document.documentElement.setAttribute("data-theme", theme); }, [theme]);
  useEffect(() => { document.documentElement.setAttribute("data-variant", variant); }, [variant]);
  useEffect(() => { document.documentElement.setAttribute("data-device", device); }, [device]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const flash = useCallback((m) => setToast(m), []);

  const onHype = useCallback((id) => {
    setHypeState(s => {
      const p = PROPOSALS.find(x => x.id === id);
      const cur = s[id] || { active:false, count:p.hype };
      const active = !cur.active;
      return { ...s, [id]: { active, count: cur.count + (active?1:-1) } };
    });
  }, []);

  const nav = useCallback((screen, param=null) => {
    setRoute({ screen, param });
    document.querySelector(".vp-scroll")?.scrollTo({ top:0, behavior:"instant" });
  }, []);

  // role change resets to a sensible screen
  const changeRole = (r) => {
    setRole(r);
    const home = (NAV_BY_ROLE[r][0] || {}).id || "feed";
    setRoute({ screen: r==="operatore" ? "operator" : r==="admin" ? "admin" : "feed", param:null });
  };

  const mobile = device === "mobile";

  // operator/admin can't open user profiles as "me"
  const openProfile = (uid) => nav("profile", uid);

  let screen;
  switch (route.screen) {
    case "feed":
      screen = <FeedScreen variant={variant} hypeState={hypeState} onHype={onHype}
        onOpen={(id)=>nav("detail",id)} mobile={mobile} />; break;
    case "detail":
      screen = <DetailScreen pid={route.param} variant={variant} hypeState={hypeState} onHype={onHype}
        onBack={()=>nav("feed")} onOpenProfile={openProfile} mobile={mobile} />; break;
    case "profile":
      screen = <ProfileScreen uid={route.param || (role==="ente"?"unitin":"anna")} variant={variant}
        hypeState={hypeState} onHype={onHype} onOpen={nav}
        isMe={!route.param && (role==="utente"||role==="ente")} mobile={mobile} />; break;
    case "create":
      screen = <CreateScreen mobile={mobile} onDone={()=>{ flash("Proposta inviata in moderazione!"); nav("feed"); }} />; break;
    case "operator":
      screen = <OperatorScreen mobile={mobile} onOpenProfile={openProfile} />; break;
    case "admin":
      screen = <AdminScreen mobile={mobile} />; break;
    default:
      screen = <FeedScreen variant={variant} hypeState={hypeState} onHype={onHype} onOpen={(id)=>nav("detail",id)} mobile={mobile} />;
  }

  return (
    <>
      {/* preview chrome */}
      <div className="pchrome">
        <div className="pbrand"><span className="pdot" />InCrowd <span style={{ color:"#8d8079", fontWeight:500 }}>· Redesign</span></div>
        <div className="pgroup">
          <span className="plabel">Ruolo</span>
          <div className="seg">
            {["utente","ente","operatore","admin"].map(r =>
              <button key={r} data-on={role===r} onClick={()=>changeRole(r)}>{ROLE_META[r].label}</button>)}
          </div>
        </div>
        <div className="pgroup">
          <span className="plabel">Stile</span>
          <div className="seg">
            {["A","B","C"].map(v =>
              <button key={v} data-on={variant===v} onClick={()=>setVariant(v)}>{STYLE_NAMES[v]}</button>)}
          </div>
        </div>
        <div className="spacer" />
        <div className="pgroup">
          <span className="plabel">Vista</span>
          <div className="seg">
            <button data-on={device==="desktop"} onClick={()=>setDevice("desktop")}>Desktop</button>
            <button data-on={device==="mobile"} onClick={()=>setDevice("mobile")}>Mobile</button>
          </div>
        </div>
        <button className="iconbtn" title="Tema" onClick={()=>setTheme(t=>t==="dark"?"light":"dark")}>
          <Icon name={theme==="dark"?"sun":"moon"} size={17} />
        </button>
      </div>

      {/* stage */}
      <div className="stage" data-device={device}>
        <div className="viewport">
          <div className="vp-scroll">
            <Navbar role={role} current={route.screen} onNav={nav} theme={theme}
              onTheme={()=>setTheme(t=>t==="dark"?"light":"dark")} mobile={mobile} />
            <main key={route.screen+route.param}>{screen}</main>
          </div>
        </div>
      </div>

      <Toast msg={toast} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);

/* ============================================================
   InCrowd — icon set (coherent line icons) + Hype
   ============================================================ */
const { useState: useStateIcon } = React;

const ICON_PATHS = {
  home:     "M3 10.5 12 3l9 7.5M5 9.5V20h5v-6h4v6h5V9.5",
  plus:     "M12 5v14M5 12h14",
  user:     "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM5 20c0-3.5 3-6 7-6s7 2.5 7 6",
  search:   "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM21 21l-4.3-4.3",
  bolt:     "M13 2 4.5 13.5H11l-1 8.5L19.5 10H13l0-8Z",
  sun:      "M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10ZM12 1v3M12 20v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M1 12h3M20 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1",
  moon:     "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z",
  logout:   "M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l5-5-5-5M15 12H3",
  chevdown: "M6 9l6 6 6-6",
  chevright:"M9 6l6 6-6 6",
  chevleft: "M15 6l-6 6 6 6",
  arrowleft:"M19 12H5M12 19l-7-7 7-7",
  arrowright:"M5 12h14M12 5l7 7-7 7",
  pin:      "M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11ZM12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  calendar: "M7 3v3M17 3v3M4 8h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z",
  comment:  "M21 12a8 8 0 0 1-11.5 7.2L4 21l1.8-5.5A8 8 0 1 1 21 12Z",
  eye:      "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7ZM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  check:    "M5 13l4 4L19 7",
  x:        "M6 6l12 12M18 6 6 18",
  shield:   "M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6l8-3Z",
  hourglass:"M6 3h12M6 21h12M7 3c0 4 3 5 5 7 2-2 5-3 5-7M7 21c0-4 3-5 5-7 2 2 5 3 5 7",
  users:    "M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM2 20c0-3 2.5-5 5-5h4c2.5 0 5 2 5 5M17 11a3 3 0 0 0 0-6M19 20c0-2.4-1-4-3-4.6",
  mail:     "M3 6h18v12H3zM3 7l9 6 9-6",
  filter:   "M3 5h18l-7 8v5l-4 2v-7L3 5Z",
  sort:     "M7 4v16M7 20l-3-3M7 4l3 3M17 20V4M17 4l3 3M17 20l-3-3",
  image:    "M4 4h16v16H4zM4 16l5-5 4 4 3-3 4 4M9 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z",
  camera:   "M4 8h3l2-2h6l2 2h3v11H4zM12 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z",
  music:    "M9 18V5l11-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",
  mic:      "M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3ZM6 11a6 6 0 0 0 12 0M12 18v3",
  masks:    "M8 4c-2.5 0-4 2-4 5s1.5 6 4 6 4-3 4-6-1.5-5-4-5ZM6.5 9h.01M9.5 9h.01M16 4c2.5 0 4 2 4 5s-1.5 6-4 6",
  activity: "M3 12h4l3 8 4-16 3 8h4",
  tool:     "M14 7a3.5 3.5 0 0 1-4.6 3.3L4 16l4 4 5.7-5.4A3.5 3.5 0 0 1 17 10l-2-2 2-2-3-1Z",
  target:   "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z",
  edit:     "M4 20h4L19 9l-4-4L4 16v4ZM14 6l4 4",
  trash:    "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6",
  trophy:   "M7 4h10v4a5 5 0 0 1-10 0V4ZM7 6H4v1a3 3 0 0 0 3 3M17 6h3v1a3 3 0 0 0-3 3M9 18h6M10 21h4M12 13v5",
  building: "M5 21V5a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16M15 21V9h3a1 1 0 0 1 1 1v11M8 8h2M8 12h2M8 16h2M3 21h18",
  send:     "M22 3 2 11l7 2 2 7 11-17ZM9 13l4-4",
  heart:    "M12 20S4 14.5 4 9a4 4 0 0 1 7.2-2.4L12 7.5l.8-.9A4 4 0 0 1 20 9c0 5.5-8 11-8 11Z",
  sparkle:  "M12 3l1.8 5.5L19 10l-5.2 1.5L12 17l-1.8-5.5L5 10l5.2-1.5L12 3Z",
  bell:     "M6 16V10a6 6 0 0 1 12 0v6l2 2H4l2-2ZM10 20a2 2 0 0 0 4 0",
  link:     "M9 15l6-6M10 6l1-1a3.5 3.5 0 0 1 5 5l-1 1M14 18l-1 1a3.5 3.5 0 0 1-5-5l1-1",
  menu:     "M4 7h16M4 12h16M4 17h16",
  globe:    "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3 12h18M12 3c2.5 2.5 2.5 15 0 18M12 3c-2.5 2.5-2.5 15 0 18",
};

function Icon({ name, size = 20, stroke = 1.75, fill = "none", className = "", style = {} }) {
  const d = ICON_PATHS[name];
  if (!d) return null;
  const solid = fill !== "none";
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={solid ? fill : "none"}
         stroke={solid ? "none" : "currentColor"} strokeWidth={stroke}
         strokeLinecap="round" strokeLinejoin="round" className={className}
         style={{ flexShrink: 0, display: "block", ...style }} aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

/* Iconic hype control — filled bolt, count bump, burst */
function Hype({ count, active, onToggle, size = "md", stacked = false }) {
  const [burst, setBurst] = useStateIcon(0);
  const sizes = {
    sm: { pad: "5px 10px", fs: 13, ic: 14 },
    md: { pad: "7px 13px", fs: 14.5, ic: 17 },
    lg: { pad: "10px 16px", fs: 17, ic: 20 },
  }[size];
  const handle = (e) => {
    e.stopPropagation();
    if (!active) setBurst(b => b + 1);
    onToggle && onToggle();
  };
  return (
    <button onClick={handle} className="hype-btn" data-active={active}
      style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        padding: sizes.pad, borderRadius: "var(--r-pill)", fontWeight: 700,
        fontSize: sizes.fs, position: "relative", lineHeight: 1,
        border: active ? "1.5px solid transparent" : "1.5px solid var(--border)",
        background: active ? "linear-gradient(135deg, var(--hype), var(--hype-deep))" : "var(--surface)",
        color: active ? "#3a2600" : "var(--ink-2)",
        boxShadow: active ? "0 4px 14px rgba(245,144,0,.35)" : "var(--shadow-sm)",
        transition: "all .2s var(--ease-back)",
      }}>
      <span style={{ position: "relative", display: "grid", placeItems: "center" }}>
        <Icon name="bolt" size={sizes.ic} fill={active ? "#3a2600" : "none"}
              stroke={active ? 0 : 1.9}
              style={{ color: active ? "#3a2600" : "var(--hype-deep)", transition: "transform .25s var(--ease-back)", transform: active ? "scale(1.08)" : "none" }} />
        {burst > 0 && <span key={burst} className="hype-burst" />}
      </span>
      <span style={{ fontVariantNumeric: "tabular-nums", minWidth: 8, textAlign: "left" }}>{count}</span>
    </button>
  );
}

const HYPE_CSS = `
.hype-btn:hover { transform: translateY(-1px); }
.hype-btn[data-active="false"]:hover { border-color: var(--hype); color: var(--hype-deep); }
.hype-burst { position:absolute; inset:-7px; border-radius:50%; pointer-events:none;
  background: radial-gradient(circle, var(--hype) 0%, transparent 60%);
  animation: hypeBurst .55s var(--ease) forwards; }
@keyframes hypeBurst { 0%{ transform:scale(.4); opacity:.9 } 100%{ transform:scale(2.2); opacity:0 } }
`;
(function(){ const s=document.createElement("style"); s.textContent=HYPE_CSS; document.head.appendChild(s); })();

Object.assign(window, { Icon, Hype });

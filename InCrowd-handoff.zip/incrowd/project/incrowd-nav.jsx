/* ============================================================
   InCrowd — role-aware navbar
   ============================================================ */

const NAV_BY_ROLE = {
  utente:    [ {id:"feed",label:"Home",icon:"home"}, {id:"create",label:"Aggiungi proposta",icon:"plus"}, {id:"profile",label:"Profilo",icon:"user"} ],
  ente:      [ {id:"feed",label:"Home",icon:"home"}, {id:"create",label:"Aggiungi proposta",icon:"plus"}, {id:"profile",label:"Profilo",icon:"building"} ],
  operatore: [ {id:"feed",label:"Home",icon:"home"}, {id:"operator",label:"Pannello Operatore",icon:"shield"} ],
  admin:     [ {id:"admin",label:"Gestione Operatori",icon:"users"} ],
};

const ROLE_META = {
  utente:    { label:"Utente",    icon:"user",     color:"var(--cat-workshop)" },
  ente:      { label:"Ente",      icon:"building", color:"var(--cat-cultura)" },
  operatore: { label:"Operatore", icon:"tool",     color:"var(--ink-2)" },
  admin:     { label:"Admin",     icon:"shield",   color:"var(--brand)" },
};

function Logo({ size = 30, light = false }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:11 }}>
      <div style={{ width:size, height:size, borderRadius:"50%", background:"var(--brand)", position:"relative", flexShrink:0,
        boxShadow:"0 3px 10px rgba(255,77,94,.4)" }}>
        <div style={{ position:"absolute", inset:size*0.2, borderRadius:"50%", background: light?"#0d0a09":"var(--ink)" }} />
        <div style={{ position:"absolute", top:"50%", left:"50%", width:size*0.17, height:size*0.17, borderRadius:"50%",
          background:"var(--brand)", transform:"translate(-50%,-50%)" }} />
      </div>
      <span style={{ fontFamily:"var(--font-display)", fontWeight:800, fontSize:size*0.66, letterSpacing:"-.03em",
        color: light?"#f5efe9":"var(--ink)" }}>InCrowd</span>
    </div>
  );
}

function Navbar({ role, current, onNav, theme, onTheme, mobile }) {
  const [menuOpen, setMenuOpen] = useStateUI(false);
  const items = NAV_BY_ROLE[role] || [];
  const rm = ROLE_META[role];
  const me = role === "operatore" ? OPERATOR : role === "admin" ? ADMIN : (role === "ente" ? USERS.unitin : USERS.anna);

  return (
    <header style={{ position:"sticky", top:0, zIndex:50,
      background:"var(--nav-bg)", backdropFilter:"blur(14px)", WebkitBackdropFilter:"blur(14px)",
      borderBottom:"1px solid var(--border)" }}>
      <div style={{ maxWidth:"var(--maxw)", margin:"0 auto", height:"var(--nav-h)",
        padding:"0 clamp(16px,4vw,28px)", display:"flex", alignItems:"center", gap: mobile?10:"var(--s-5)" }}>
        <button onClick={() => onNav(items[0]?.id || "feed")} style={{ display:"flex" }}><Logo /></button>

        {rm && !mobile && (
          <span style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"5px 11px",
            borderRadius:"var(--r-pill)", background:"var(--surface-3)", fontSize:12.5, fontWeight:700,
            color:rm.color }}>
            <Icon name={rm.icon} size={13} stroke={2.2} />{rm.label}
          </span>
        )}

        {!mobile && (
          <nav style={{ display:"flex", alignItems:"center", gap:4, marginLeft:8 }}>
            {items.map(it => {
              const on = current === it.id;
              return (
                <button key={it.id} onClick={() => onNav(it.id)}
                  style={{ display:"inline-flex", alignItems:"center", gap:7, padding:"9px 14px",
                    borderRadius:"var(--r-pill)", fontSize:14.5, fontWeight:on?700:600,
                    color: on?"var(--brand-700)":"var(--ink-2)", background: on?"var(--brand-soft)":"transparent",
                    transition:"all .16s var(--ease)" }}>
                  <Icon name={it.icon} size={16} stroke={on?2.2:1.8} />{it.label}
                </button>
              );
            })}
          </nav>
        )}

        <div style={{ flex:1 }} />

        <button onClick={onTheme} title="Cambia tema" className="ic-btn"
          style={{ width:40, height:40, borderRadius:"50%", border:"1px solid var(--border)",
            background:"var(--surface)", display:"grid", placeItems:"center", color:"var(--ink-2)" }}>
          <Icon name={theme==="dark"?"sun":"moon"} size={18} />
        </button>

        <div style={{ position:"relative" }}>
          <button onClick={() => setMenuOpen(o=>!o)}
            style={{ display:"flex", alignItems:"center", gap:9, padding:"5px 7px 5px 5px",
              borderRadius:"var(--r-pill)", background:"var(--surface)", border:"1px solid var(--border)",
              boxShadow:"var(--shadow-sm)" }}>
            <Avatar user={me} size={32} />
            {!mobile && <span style={{ fontWeight:700, fontSize:14 }}>{me.name.length>16?me.name.slice(0,15)+"…":me.name}</span>}
            <Icon name="chevdown" size={15} style={{ color:"var(--ink-3)", marginRight:3 }} />
          </button>
          {menuOpen && (
            <>
              <div onClick={()=>setMenuOpen(false)} style={{ position:"fixed", inset:0, zIndex:1 }} />
              <div className="fade-in" style={{ position:"absolute", right:0, top:"calc(100% + 8px)", zIndex:2,
                background:"var(--surface)", border:"1px solid var(--border)", borderRadius:"var(--r-md)",
                boxShadow:"var(--shadow-lg)", padding:7, minWidth:210 }}>
                <div style={{ padding:"9px 11px", display:"flex", alignItems:"center", gap:10 }}>
                  <Avatar user={me} size={38} />
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontWeight:700, fontSize:14, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{me.name}</div>
                    <div style={{ fontSize:12, color:"var(--ink-3)", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{me.email}</div>
                  </div>
                </div>
                <div style={{ height:1, background:"var(--border)", margin:"4px 0" }} />
                {(role==="utente"||role==="ente") && (
                  <button onClick={()=>{onNav("profile");setMenuOpen(false);}} className="menu-row"><Icon name="user" size={17}/>Il mio profilo</button>
                )}
                <button onClick={onTheme} className="menu-row"><Icon name={theme==="dark"?"sun":"moon"} size={17}/>Tema {theme==="dark"?"chiaro":"scuro"}</button>
                <button className="menu-row" style={{ color:"var(--brand-700)" }}><Icon name="logout" size={17}/>Esci</button>
              </div>
            </>
          )}
        </div>
      </div>

      {mobile && items.length > 1 && (
        <div style={{ display:"flex", gap:4, padding:"0 14px 12px", overflowX:"auto" }}>
          {items.map(it => {
            const on = current === it.id;
            return (
              <button key={it.id} onClick={()=>onNav(it.id)}
                style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"8px 13px", whiteSpace:"nowrap",
                  borderRadius:"var(--r-pill)", fontSize:13.5, fontWeight:on?700:600,
                  color:on?"#fff":"var(--ink-2)", background:on?"var(--brand)":"var(--surface-3)" }}>
                <Icon name={it.icon} size={15} />{it.label}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
}

const NAV_CSS = `
.menu-row { display:flex; align-items:center; gap:11px; width:100%; padding:10px 11px; border-radius:10px;
  font-size:14px; font-weight:600; color:var(--ink-2); transition:background .14s; }
.menu-row:hover { background:var(--surface-3); }
`;
(function(){ const s=document.createElement("style"); s.textContent=NAV_CSS; document.head.appendChild(s); })();

Object.assign(window, { Navbar, Logo, NAV_BY_ROLE, ROLE_META });

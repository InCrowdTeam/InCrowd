/* ============================================================
   InCrowd — Feed / Home (hero screen)
   ============================================================ */
const { useState: useStateFeed, useMemo: useMemoFeed } = React;

/* ---------- Proposal card (3 style variants) ---------- */
function ProposalCard({ p, variant, hyped, count, onHype, onOpen, mobile }) {
  const author = USERS[p.author];
  const cat = CATEGORIES[p.cat];

  /* ---- Variant C: magazine / image-overlay ---- */
  if (variant === "C") {
    return (
      <article className="ic-card-hover" onClick={() => onOpen(p.id)}
        style={{ position:"relative", borderRadius:"var(--r-lg)", overflow:"hidden", cursor:"pointer",
          aspectRatio: mobile?"16/13":"1/1.18", border:"1px solid var(--border)", boxShadow:"var(--shadow-sm)",
          transition:"all .22s var(--ease)" }}>
        <ImgPlaceholder cat={p.cat} label={cat.label.toLowerCase()} radius="0"
          style={{ position:"absolute", inset:0, aspectRatio:"auto", height:"100%" }} />
        <div style={{ position:"absolute", inset:0, background:"linear-gradient(180deg, rgba(10,8,7,.05) 0%, rgba(10,8,7,.15) 45%, rgba(10,8,7,.86) 100%)" }} />
        <div style={{ position:"absolute", top:14, left:14, right:14, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
          <CatTag cat={p.cat} solid size="sm" />
          <div onClick={e=>e.stopPropagation()}><Hype count={count} active={hyped} onToggle={onHype} size="sm" /></div>
        </div>
        <div style={{ position:"absolute", left:16, right:16, bottom:15, color:"#fff" }}>
          <h3 style={{ fontSize:mobile?19:21, fontWeight:700, lineHeight:1.08, marginBottom:8, textWrap:"balance", textShadow:"0 2px 12px rgba(0,0,0,.4)" }}>{p.title}</h3>
          <div style={{ display:"flex", alignItems:"center", gap:7, fontSize:13, color:"rgba(255,255,255,.9)", fontWeight:600 }}>
            <Icon name="pin" size={14} />{p.place}
          </div>
        </div>
      </article>
    );
  }

  const tinted = variant === "B";
  return (
    <article className="ic-card-hover" onClick={() => onOpen(p.id)}
      style={{ display:"flex", flexDirection:"column", borderRadius:"var(--r-lg)", overflow:"hidden", cursor:"pointer",
        background: tinted ? cat.soft : "var(--surface)",
        border:`1px solid ${tinted ? "transparent" : "var(--border)"}`,
        boxShadow:"var(--shadow-sm)", transition:"all .22s var(--ease)" }}>
      <div style={{ position:"relative", padding: tinted?"10px 10px 0":"0" }}>
        <ImgPlaceholder cat={p.cat} label={cat.label.toLowerCase()} radius={tinted?"var(--r-md)":"0"} ratio="16/10" />
        <div style={{ position:"absolute", top: tinted?18:12, left: tinted?18:12 }}>
          <CatTag cat={p.cat} solid={variant==="B"} size="sm" />
        </div>
        <div style={{ position:"absolute", top: tinted?16:10, right: tinted?16:10 }} onClick={e=>e.stopPropagation()}>
          <Hype count={count} active={hyped} onToggle={onHype} size="sm" />
        </div>
      </div>
      <div style={{ padding:"15px 16px 16px", display:"flex", flexDirection:"column", flex:1, gap:9 }}>
        <h3 style={{ fontSize:17.5, fontWeight:700, lineHeight:1.12, color:"var(--ink)", textWrap:"balance" }}>{p.title}</h3>
        <p style={{ fontSize:13.5, color:"var(--ink-2)", lineHeight:1.45, display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{p.short}</p>
        <div style={{ flex:1 }} />
        <div style={{ height:1, background: tinted?"color-mix(in srgb, var(--ink) 8%, transparent)":"var(--border)" }} />
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8 }}>
          <div style={{ display:"flex", alignItems:"center", gap:7, minWidth:0 }}>
            <Avatar user={author} size={24} />
            <span style={{ fontSize:12.5, color:"var(--ink-3)", fontWeight:600, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{author.name}</span>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:5, fontSize:12.5, color:"var(--ink-3)", fontWeight:600, flexShrink:0 }}>
            <Icon name="pin" size={13} />{p.place}
          </div>
        </div>
      </div>
    </article>
  );
}

/* ---------- Feed screen ---------- */
function FeedScreen({ variant, hypeState, onHype, onOpen, mobile }) {
  const [tab, setTab] = useStateFeed("esplora");
  const [query, setQuery] = useStateFeed("");
  const [activeCats, setActiveCats] = useStateFeed([]);

  const approved = PROPOSALS.filter(p => p.status === "approvata");

  const list = useMemoFeed(() => {
    let l = [...approved];
    if (tab === "classifica") l.sort((a,b) => (hypeState[b.id]?.count||b.hype) - (hypeState[a.id]?.count||a.hype));
    if (tab === "seguiti") l = l.filter(p => ["giacomo","corpo","unitin"].includes(p.author));
    if (query.trim()) { const q = query.toLowerCase(); l = l.filter(p => (p.title+p.short+p.place).toLowerCase().includes(q)); }
    if (activeCats.length) l = l.filter(p => activeCats.includes(p.cat));
    return l;
  }, [tab, query, activeCats, hypeState]);

  const toggleCat = (c) => setActiveCats(a => a.includes(c) ? a.filter(x=>x!==c) : [...a, c]);
  const getCount = (p) => hypeState[p.id]?.count ?? p.hype;

  return (
    <div style={{ maxWidth:"var(--maxw)", margin:"0 auto", padding:"clamp(18px,3vw,30px) clamp(14px,4vw,28px) 80px" }}>
      {/* search */}
      <Card pad={mobile?"16px":"22px 24px"} style={{ marginBottom:"var(--s-5)", borderRadius:"var(--r-lg)" }}>
        <div style={{ display:"flex", gap:12, alignItems:"center", flexWrap:"wrap" }}>
          <div style={{ position:"relative", flex:1, minWidth:200 }}>
            <Icon name="search" size={19} style={{ position:"absolute", left:15, top:"50%", transform:"translateY(-50%)", color:"var(--ink-3)" }} />
            <input className="ic-input" value={query} onChange={e=>setQuery(e.target.value)}
              placeholder="Cerca proposte per titolo, luogo o descrizione…" style={{ paddingLeft:44, borderRadius:"var(--r-pill)" }} />
          </div>
          {!mobile && <Btn variant="ghost" icon="filter">Filtri</Btn>}
        </div>
      </Card>

      <div style={{ display:"flex", justifyContent:"center", marginBottom:"var(--s-6)" }}>
        <PillTabs active={tab} onChange={setTab} tabs={[
          {id:"esplora",label:"Esplora",icon:"globe"},
          {id:"seguiti",label:"Seguiti",icon:"heart"},
          {id:"classifica",label:"Classifica",icon:"trophy"},
        ]} />
      </div>

      {/* banner */}
      <div style={{ position:"relative", overflow:"hidden", borderRadius:"var(--r-lg)", marginBottom:"var(--s-6)",
        background:"linear-gradient(110deg, var(--brand) 0%, var(--brand-700) 60%, #7a1d2e 100%)",
        padding: mobile?"22px 20px":"30px 34px", color:"#fff", boxShadow:"0 12px 34px rgba(255,77,94,.28)" }}>
        <div style={{ position:"absolute", right:-30, top:-40, width:200, height:200, borderRadius:"50%", background:"rgba(255,255,255,.1)" }} />
        <div style={{ position:"absolute", right:90, bottom:-60, width:150, height:150, borderRadius:"50%", background:"rgba(255,255,255,.07)" }} />
        <div style={{ display:"flex", alignItems:"center", gap:10, position:"relative" }}>
          <Icon name="sparkle" size={26} fill="#fff" stroke={0} />
          <h2 style={{ fontSize:mobile?22:28, fontWeight:800 }}>{tab==="classifica"?"Le più sostenute":tab==="seguiti"?"Dai tuoi seguiti":"Nuove Proposte"}</h2>
        </div>
        <p style={{ marginTop:6, fontSize:mobile?14:15.5, color:"rgba(255,255,255,.92)", position:"relative" }}>
          {tab==="classifica"?"Le idee che la community sta spingendo di più":tab==="seguiti"?"Le ultime idee da chi segui":"Scopri le ultime idee della community"}
        </p>
      </div>

      {/* category filter chips */}
      <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:"var(--s-6)" }}>
        <button onClick={()=>setActiveCats([])}
          style={{ padding:"8px 15px", borderRadius:"var(--r-pill)", fontSize:13.5, fontWeight:700,
            border:"1px solid var(--border)", transition:"all .16s var(--ease)",
            color: activeCats.length===0?"#fff":"var(--ink-2)",
            background: activeCats.length===0?"var(--ink)":"var(--surface)" }}>Tutte</button>
        {CAT_ORDER.map(c => {
          const on = activeCats.includes(c);
          const cc = CATEGORIES[c];
          return (
            <button key={c} onClick={()=>toggleCat(c)}
              style={{ display:"inline-flex", alignItems:"center", gap:7, padding:"8px 15px", borderRadius:"var(--r-pill)",
                fontSize:13.5, fontWeight:700, transition:"all .16s var(--ease)",
                border:`1px solid ${on?"transparent":"var(--border)"}`,
                color: on?"#fff":cc.color, background: on?cc.color:"var(--surface)" }}>
              <Icon name={cc.icon} size={15} stroke={2}/>{cc.label}
            </button>
          );
        })}
      </div>

      {/* grid */}
      {list.length === 0 ? (
        <EmptyState query={query} />
      ) : (
        <div style={{ display:"grid", gap: mobile?16:"var(--s-5)",
          gridTemplateColumns: mobile ? "1fr" : "repeat(auto-fill, minmax(258px, 1fr))" }}>
          {list.map((p,i) => (
            <div key={p.id} className="fade-in" style={{ animationDelay:`${Math.min(i*45,360)}ms` }}>
              {tab==="classifica" && !mobile && (
                <div style={{ fontFamily:"var(--font-display)", fontWeight:800, fontSize:13, color:"var(--ink-3)", marginBottom:6, paddingLeft:4 }}>#{i+1}</div>
              )}
              <ProposalCard p={p} variant={variant} hyped={!!hypeState[p.id]?.active} count={getCount(p)}
                onHype={()=>onHype(p.id)} onOpen={onOpen} mobile={mobile} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyState({ query }) {
  return (
    <div style={{ textAlign:"center", padding:"70px 20px", color:"var(--ink-3)" }}>
      <div style={{ width:72, height:72, borderRadius:"50%", background:"var(--surface-3)", display:"grid", placeItems:"center", margin:"0 auto 18px" }}>
        <Icon name="search" size={30} />
      </div>
      <h3 style={{ fontSize:20, color:"var(--ink)", marginBottom:6 }}>Nessuna proposta trovata</h3>
      <p style={{ fontSize:14.5 }}>{query?`Nessun risultato per “${query}”.`:"Prova a cambiare i filtri."}</p>
    </div>
  );
}

Object.assign(window, { FeedScreen, ProposalCard });

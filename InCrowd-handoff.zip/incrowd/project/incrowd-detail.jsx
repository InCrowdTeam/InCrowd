/* ============================================================
   InCrowd — Proposal detail
   ============================================================ */
const { useState: useStateDetail } = React;

function DetailScreen({ pid, variant, hypeState, onHype, onBack, onOpenProfile, mobile }) {
  const p = PROPOSALS.find(x => x.id === pid) || PROPOSALS[0];
  const author = USERS[p.author];
  const cat = CATEGORIES[p.cat];
  const count = hypeState[p.id]?.count ?? p.hype;
  const active = !!hypeState[p.id]?.active;
  const [comments, setComments] = useStateDetail(COMMENTS[p.id] || []);
  const [draft, setDraft] = useStateDetail("");
  const supporters = (p.supporters||[]).map(id => USERS[id]).filter(Boolean);

  const post = () => {
    if (!draft.trim()) return;
    setComments(c => [{ id:"new"+Date.now(), user:"anna", text:draft.trim(), time:"adesso", replies:[] }, ...c]);
    setDraft("");
  };

  return (
    <div style={{ maxWidth:860, margin:"0 auto", padding:"clamp(16px,3vw,28px) clamp(14px,4vw,24px) 80px", display:"flex", flexDirection:"column", gap:"var(--s-5)" }}>
      {/* hero card */}
      <Card pad="0" style={{ overflow:"hidden" }} className="fade-in">
        <div style={{ position:"relative" }}>
          <ImgPlaceholder cat={p.cat} label={cat.label.toLowerCase()} radius="0" ratio={mobile?"16/10":"21/9"} />
          <div style={{ position:"absolute", top:16, left:16 }}><CatTag cat={p.cat} solid /></div>
          <button onClick={onBack} style={{ position:"absolute", top:16, right:16, display:"inline-flex", alignItems:"center", gap:6,
            padding:"8px 14px", borderRadius:"var(--r-pill)", background:"var(--ink)", color:"var(--ink-inv)", fontWeight:700, fontSize:13.5,
            boxShadow:"var(--shadow-md)" }}>
            <Icon name="arrowleft" size={16} />Indietro
          </button>
        </div>
        <div style={{ padding:"clamp(20px,3vw,30px)" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:20, flexWrap:"wrap" }}>
            <h1 style={{ fontSize:"clamp(26px,4vw,38px)", fontWeight:800, color:"var(--ink)", textWrap:"balance", flex:1, minWidth:240 }}>{p.title}</h1>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:6 }}>
              <Hype count={count} active={active} onToggle={()=>onHype(p.id)} size="lg" />
              <span style={{ fontSize:11.5, color:"var(--ink-3)", fontWeight:700, textTransform:"uppercase", letterSpacing:".05em" }}>Hype</span>
            </div>
          </div>

          <button onClick={()=>onOpenProfile(author.id)} style={{ display:"inline-flex", alignItems:"center", gap:10, marginTop:16,
            padding:"7px 14px 7px 7px", borderRadius:"var(--r-pill)", background:"var(--brand-soft)", transition:"all .16s var(--ease)" }} className="ic-btn">
            <Avatar user={author} size={34} />
            <div style={{ textAlign:"left" }}>
              <div style={{ fontSize:10.5, color:"var(--ink-3)", fontWeight:700, textTransform:"uppercase", letterSpacing:".06em" }}>Proposto da</div>
              <div style={{ fontSize:14.5, fontWeight:700, color:"var(--brand-700)" }}>{author.name}</div>
            </div>
          </button>

          <p style={{ marginTop:18, fontSize:16, lineHeight:1.6, color:"var(--ink-2)", maxWidth:640 }}>{p.body}</p>

          {/* info grid */}
          <div style={{ display:"grid", gap:14, gridTemplateColumns: mobile?"1fr":"1fr 1fr", marginTop:24 }}>
            <InfoBox icon="pin" label="Dove" title={p.place}>
              <div style={{ fontSize:13.5, color:"var(--ink-2)" }}>{p.address}</div>
              <Badge style={{ marginTop:8 }}>CAP {p.cap}</Badge>
            </InfoBox>
            <InfoBox icon="calendar" label="Quando" title={p.date} />
          </div>
          <div style={{ display:"flex", justifyContent:"flex-end", marginTop:16 }}>
            <Badge icon="edit">Creata {p.created}</Badge>
          </div>
        </div>
      </Card>

      {/* supporters */}
      {supporters.length > 0 && (
        <Card className="fade-in">
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
            <div style={{ display:"flex", alignItems:"center", gap:9 }}>
              <span style={{ width:34, height:34, borderRadius:10, background:"var(--hype)", display:"grid", placeItems:"center", boxShadow:"0 3px 9px rgba(245,144,0,.4)" }}>
                <Icon name="bolt" size={18} fill="#3a2600" stroke={0} />
              </span>
              <h2 style={{ fontSize:19, fontWeight:700 }}>Enti che sostengono</h2>
            </div>
            <Badge color="#fff" bg="var(--brand)">{supporters.length} {supporters.length===1?"Ente":"Enti"}</Badge>
          </div>
          <div style={{ display:"grid", gap:12, gridTemplateColumns: mobile?"1fr":"repeat(auto-fill,minmax(220px,1fr))" }}>
            {supporters.map(s => (
              <button key={s.id} onClick={()=>onOpenProfile(s.id)} className="ic-card-hover"
                style={{ display:"flex", gap:11, alignItems:"center", padding:13, borderRadius:"var(--r-md)",
                  background:"var(--surface-2)", border:"1px solid var(--border)", textAlign:"left" }}>
                <Avatar user={s} size={42} />
                <div style={{ minWidth:0 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                    <span style={{ fontWeight:700, fontSize:14, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{s.name}</span>
                  </div>
                  <div style={{ fontSize:12, color:"var(--ink-3)", display:"-webkit-box", WebkitLineClamp:1, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{s.bio}</div>
                </div>
              </button>
            ))}
          </div>
        </Card>
      )}

      {/* comments */}
      <Card className="fade-in">
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:18 }}>
          <div style={{ display:"flex", alignItems:"center", gap:9 }}>
            <Icon name="comment" size={22} stroke={2} style={{ color:"var(--brand)" }} />
            <h2 style={{ fontSize:19, fontWeight:700 }}>Commenti</h2>
          </div>
          <Badge color="#fff" bg="var(--brand)">{comments.length} {comments.length===1?"commento":"commenti"}</Badge>
        </div>

        <div style={{ display:"flex", gap:11, marginBottom:22 }}>
          <Avatar user={USERS.anna} size={40} />
          <div style={{ flex:1 }}>
            <textarea className="ic-input" value={draft} onChange={e=>setDraft(e.target.value)} rows={3}
              onKeyDown={e=>{ if((e.ctrlKey||e.metaKey)&&e.key==="Enter") post(); }}
              placeholder="Scrivi un commento…" style={{ resize:"vertical", minHeight:74 }} />
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:9 }}>
              <span style={{ fontSize:12, color:"var(--ink-3)" }} className="mono">{draft.length}/500 · Ctrl+Invio</span>
              <Btn icon="send" size="sm" onClick={post} disabled={!draft.trim()}>Pubblica</Btn>
            </div>
          </div>
        </div>

        {comments.length === 0 ? (
          <div style={{ textAlign:"center", padding:"30px", color:"var(--ink-3)" }}>
            <Icon name="comment" size={30} style={{ opacity:.4, margin:"0 auto 10px" }} />
            <div style={{ fontWeight:700, color:"var(--ink-2)" }}>Nessun commento ancora</div>
            <div style={{ fontSize:13.5 }}>Sii il primo a commentare questa proposta!</div>
          </div>
        ) : (
          <div style={{ display:"flex", flexDirection:"column", gap:18 }}>
            {comments.map(c => <CommentThread key={c.id} c={c} />)}
          </div>
        )}
      </Card>
    </div>
  );
}

function InfoBox({ icon, label, title, children }) {
  return (
    <div style={{ background:"var(--surface-2)", border:"1px solid var(--border)", borderRadius:"var(--r-md)", padding:16 }}>
      <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:8 }}>
        <Icon name={icon} size={15} stroke={2} style={{ color:"var(--brand)" }} />
        <span style={{ fontSize:11, fontWeight:800, color:"var(--ink-3)", textTransform:"uppercase", letterSpacing:".07em" }}>{label}</span>
      </div>
      <div style={{ fontSize:16, fontWeight:700, color:"var(--ink)" }}>{title}</div>
      {children}
    </div>
  );
}

function CommentThread({ c, reply }) {
  const u = USERS[c.user];
  return (
    <div style={{ display:"flex", gap:11, marginLeft: reply?42:0 }}>
      <Avatar user={u} size={reply?30:38} />
      <div style={{ flex:1 }}>
        <div style={{ background: reply?"var(--surface-2)":"var(--surface-3)", borderRadius:"var(--r-md)", padding:"11px 14px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
            <span style={{ fontWeight:700, fontSize:13.5 }}>{u.name}</span>
            {u.type==="ente" && <Badge color="var(--cat-cultura)" bg="var(--cat-cultura-soft)">Ente</Badge>}
            <span style={{ fontSize:11.5, color:"var(--ink-3)" }}>· {c.time}</span>
          </div>
          <p style={{ fontSize:14, color:"var(--ink-2)", lineHeight:1.45 }}>{c.text}</p>
        </div>
        {c.replies && c.replies.length > 0 && (
          <div style={{ marginTop:12, display:"flex", flexDirection:"column", gap:12 }}>
            {c.replies.map(r => <CommentThread key={r.id} c={r} reply />)}
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { DetailScreen });

/* ============================================================
   InCrowd — Operator panel + Admin
   ============================================================ */
const { useState: useStateOp } = React;

function StatCard({ icon, n, label, sub, color }) {
  return (
    <Card pad="18px 20px" style={{ position:"relative", overflow:"hidden" }}>
      <div style={{ position:"absolute", left:0, top:0, bottom:0, width:5, background:color }} />
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:12 }}>
        <div style={{ width:44, height:44, borderRadius:13, background:`color-mix(in srgb, ${color} 14%, transparent)`, display:"grid", placeItems:"center" }}>
          <Icon name={icon} size={22} stroke={2} style={{ color }} />
        </div>
      </div>
      <div style={{ fontFamily:"var(--font-display)", fontWeight:800, fontSize:34, lineHeight:1, color:"var(--ink)" }}>{n}</div>
      <div style={{ fontSize:15, fontWeight:700, marginTop:7 }}>{label}</div>
      <div style={{ fontSize:13, color:"var(--ink-3)", marginTop:2 }}>{sub}</div>
    </Card>
  );
}

function OperatorScreen({ mobile, onOpenProfile }) {
  const [view, setView] = useStateOp("panel");
  const pending = PROPOSALS.filter(p => p.status === "in_approvazione");

  return (
    <div style={{ maxWidth:"var(--maxw)", margin:"0 auto", padding:"clamp(16px,3vw,28px) clamp(14px,4vw,28px) 80px", display:"flex", flexDirection:"column", gap:"var(--s-6)" }}>
      {/* hero banner */}
      <div style={{ position:"relative", overflow:"hidden", borderRadius:"var(--r-lg)",
        background:"linear-gradient(110deg, var(--ink) 0%, #3a2a24 100%)", color:"#fff",
        padding: mobile?"24px 22px":"34px 38px" }}>
        <div style={{ position:"absolute", right:-30, top:-50, width:200, height:200, borderRadius:"50%", background:"rgba(255,77,94,.18)" }} />
        <div style={{ display:"flex", alignItems:"center", gap:16, position:"relative" }}>
          <div style={{ width:54, height:54, borderRadius:16, background:"var(--brand)", display:"grid", placeItems:"center", boxShadow:"0 6px 18px rgba(255,77,94,.5)" }}>
            <Icon name="shield" size={28} stroke={2} />
          </div>
          <div>
            <h1 style={{ fontSize:mobile?24:30, fontWeight:800 }}>Pannello Operatore</h1>
            <p style={{ color:"rgba(255,255,255,.82)", marginTop:5, fontSize:mobile?14:15.5 }}>Gestisci la community e mantieni un ambiente sicuro per tutti</p>
          </div>
        </div>
      </div>

      {/* sub-nav */}
      <PillTabs active={view} onChange={setView} tabs={[
        {id:"panel",label:"Panoramica",icon:"home"},
        {id:"moderation",label:"Moderazione",icon:"search"},
        {id:"users",label:"Utenti ed enti",icon:"users"},
      ]} />

      {view === "panel" && <OperatorPanel mobile={mobile} pending={pending.length} onView={setView} />}
      {view === "moderation" && <Moderation pending={pending} mobile={mobile} />}
      {view === "users" && <UserList mobile={mobile} onOpenProfile={onOpenProfile} />}
    </div>
  );
}

function OperatorPanel({ mobile, pending, onView }) {
  return (
    <div className="fade-in" style={{ display:"flex", flexDirection:"column", gap:"var(--s-6)" }}>
      <div>
        <SectionTitle>Panoramica</SectionTitle>
        <div style={{ display:"grid", gap:"var(--s-4)", gridTemplateColumns: mobile?"1fr 1fr":"repeat(4,1fr)" }}>
          <StatCard icon="hourglass" n={pending} label="Proposte in attesa" sub="Richiedono moderazione" color="var(--brand)" />
          <StatCard icon="check" n={STATS.approvate} label="Proposte approvate" sub="Totale pubblicate" color="var(--cat-sport)" />
          <StatCard icon="users" n={STATS.utenti+STATS.enti} label="Utenti registrati" sub="Community totale" color="var(--cat-workshop)" />
          <StatCard icon="x" n={STATS.rifiutate} label="Proposte rifiutate" sub="Totale respinte" color="var(--cat-mostre)" />
        </div>
      </div>
      <div>
        <SectionTitle>Strumenti operatore</SectionTitle>
        <div style={{ display:"grid", gap:"var(--s-4)", gridTemplateColumns: mobile?"1fr":"repeat(3,1fr)" }}>
          <ToolCard featured icon="search" title="Moderazione proposte" badge={pending}
            desc="Revisiona, approva o rifiuta le proposte degli utenti. Mantieni la qualità dei contenuti."
            stat={`${pending} in attesa`} cta="Inizia moderazione" onClick={()=>onView("moderation")} />
          <ToolCard icon="users" title="Gestione utenti" color="var(--cat-workshop)"
            desc="Visualizza e gestisci la lista degli utenti registrati. Monitora l'attività della community."
            stat={`${STATS.utenti+STATS.enti} totali`} cta="Visualizza utenti" onClick={()=>onView("users")} />
          <ToolCard icon="comment" title="Ultimi commenti" color="var(--cat-cultura)"
            desc="Visualizza gli ultimi commenti inseriti dagli utenti su tutte le proposte."
            stat={`${STATS.commenti} commenti`} cta="Visualizza commenti" onClick={()=>onView("moderation")} />
        </div>
      </div>
    </div>
  );
}

function ToolCard({ featured, icon, title, desc, stat, cta, badge, color = "var(--brand)", onClick }) {
  return (
    <button onClick={onClick} className="ic-card-hover" style={{ textAlign:"left", borderRadius:"var(--r-lg)", overflow:"hidden",
      padding:"22px 22px 20px", display:"flex", flexDirection:"column", gap:12, position:"relative",
      border:`1px solid ${featured?"transparent":"var(--border)"}`, boxShadow:"var(--shadow-sm)",
      background: featured?"linear-gradient(135deg, var(--brand), var(--brand-700))":"var(--surface)",
      color: featured?"#fff":"var(--ink)" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
        <div style={{ width:48, height:48, borderRadius:14, display:"grid", placeItems:"center",
          background: featured?"rgba(255,255,255,.18)":`color-mix(in srgb, ${color} 14%, transparent)` }}>
          <Icon name={icon} size={24} stroke={2} style={{ color: featured?"#fff":color }} />
        </div>
        {badge>0 && <span style={{ minWidth:26, height:26, padding:"0 8px", borderRadius:13, display:"grid", placeItems:"center",
          background: featured?"#fff":"var(--brand)", color: featured?"var(--brand)":"#fff", fontWeight:800, fontSize:13 }}>{badge}</span>}
      </div>
      <h3 style={{ fontSize:19, fontWeight:700 }}>{title}</h3>
      <p style={{ fontSize:14, lineHeight:1.5, color: featured?"rgba(255,255,255,.9)":"var(--ink-2)", flex:1 }}>{desc}</p>
      <div style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"6px 12px", borderRadius:"var(--r-pill)", alignSelf:"flex-start",
        background: featured?"rgba(255,255,255,.18)":"var(--surface-3)", fontSize:12.5, fontWeight:700 }}>{stat}</div>
      <div style={{ display:"flex", alignItems:"center", gap:7, fontWeight:700, fontSize:14.5, marginTop:4,
        color: featured?"#fff":color }}>{cta}<Icon name="arrowright" size={16} /></div>
    </button>
  );
}

function Moderation({ pending, mobile }) {
  const [items, setItems] = useStateOp(pending);
  const act = (id) => setItems(l => l.filter(p => p.id !== id));

  return (
    <div className="fade-in" style={{ display:"flex", flexDirection:"column", gap:"var(--s-5)" }}>
      <SectionTitle sub="Revisiona e gestisci le proposte in attesa di approvazione">Moderazione proposte</SectionTitle>
      {items.length === 0 ? (
        <Card pad="50px" style={{ textAlign:"center" }}>
          <div style={{ width:64, height:64, borderRadius:"50%", background:"var(--cat-sport-soft)", display:"grid", placeItems:"center", margin:"0 auto 14px" }}>
            <Icon name="check" size={30} stroke={2.5} style={{ color:"var(--cat-sport)" }} />
          </div>
          <h3 style={{ fontSize:20 }}>Tutto pulito!</h3>
          <p style={{ color:"var(--ink-3)", marginTop:6 }}>Nessuna proposta in attesa di moderazione.</p>
        </Card>
      ) : (
        <div style={{ display:"grid", gap:"var(--s-5)", gridTemplateColumns: mobile?"1fr":"repeat(auto-fill,minmax(330px,1fr))" }}>
          {items.map(p => {
            const author = USERS[p.author]; const cat = CATEGORIES[p.cat];
            return (
              <Card key={p.id} pad="0" style={{ overflow:"hidden" }}>
                <div style={{ position:"relative" }}>
                  <ImgPlaceholder cat={p.cat} label={cat.label.toLowerCase()} radius="0" ratio="16/9" />
                  <div style={{ position:"absolute", top:12, left:12 }}><CatTag cat={p.cat} solid size="sm" /></div>
                  <div style={{ position:"absolute", top:12, right:12 }}><Badge color="var(--hype-deep)" bg="#fff7e6" icon="hourglass">In attesa</Badge></div>
                </div>
                <div style={{ padding:18 }}>
                  <h3 style={{ fontSize:18, fontWeight:700, marginBottom:8 }}>{p.title}</h3>
                  <p style={{ fontSize:13.5, color:"var(--ink-2)", lineHeight:1.5, display:"-webkit-box", WebkitLineClamp:3, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{p.body}</p>
                  <div style={{ display:"flex", alignItems:"center", gap:8, margin:"14px 0", padding:"10px 12px", borderRadius:"var(--r-sm)", background:"var(--surface-2)" }}>
                    <Avatar user={author} size={28} />
                    <span style={{ fontSize:13, fontWeight:600, color:"var(--ink-2)" }}>{author.name}</span>
                    <span style={{ flex:1 }} />
                    <Icon name="pin" size={14} style={{ color:"var(--ink-3)" }} /><span style={{ fontSize:13, color:"var(--ink-3)" }}>{p.place}</span>
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:9 }}>
                    <Btn variant="success" icon="check" size="sm" onClick={()=>act(p.id)}>Approva</Btn>
                    <Btn variant="danger" icon="x" size="sm" onClick={()=>act(p.id)}>Rifiuta</Btn>
                    <Btn variant="ghost" icon="eye" size="sm">Dettagli</Btn>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function UserList({ mobile, onOpenProfile }) {
  const [q, setQ] = useStateOp("");
  const [filter, setFilter] = useStateOp("all");
  const all = Object.values(USERS);
  const list = all.filter(u => (filter==="all"||u.type===filter) && (u.name+u.bio).toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="fade-in" style={{ display:"flex", flexDirection:"column", gap:"var(--s-5)" }}>
      <SectionTitle sub="Visualizza e gestisci tutti gli utenti ed enti registrati">Gestione utenti ed enti</SectionTitle>
      <Card pad="16px">
        <div style={{ display:"flex", gap:12, flexWrap:"wrap", alignItems:"center" }}>
          <div style={{ position:"relative", flex:1, minWidth:200 }}>
            <Icon name="search" size={18} style={{ position:"absolute", left:14, top:"50%", transform:"translateY(-50%)", color:"var(--ink-3)" }} />
            <input className="ic-input" value={q} onChange={e=>setQ(e.target.value)} placeholder="Cerca per nome o bio…" style={{ paddingLeft:42, borderRadius:"var(--r-pill)" }} />
          </div>
          <div style={{ display:"inline-flex", background:"var(--surface-3)", borderRadius:"var(--r-pill)", padding:4, gap:3 }}>
            {[{id:"all",l:"Tutti"},{id:"utente",l:"Utenti"},{id:"ente",l:"Enti"}].map(f=>(
              <button key={f.id} onClick={()=>setFilter(f.id)} style={{ padding:"8px 15px", borderRadius:"var(--r-pill)", fontSize:13.5, fontWeight:700,
                color: filter===f.id?"#fff":"var(--ink-2)", background: filter===f.id?"var(--brand)":"transparent" }}>{f.l}</button>
            ))}
          </div>
        </div>
      </Card>
      <div style={{ display:"grid", gap:"var(--s-4)", gridTemplateColumns: mobile?"1fr":"repeat(auto-fill,minmax(300px,1fr))" }}>
        {list.map(u => (
          <Card key={u.id} pad="0" style={{ overflow:"hidden" }}>
            <div style={{ height:54, background:`linear-gradient(115deg, ${u.tint}, color-mix(in srgb,${u.tint} 50%, var(--brand)))` }} />
            <div style={{ padding:"0 18px 18px", marginTop:-26 }}>
              <Avatar user={u} size={56} />
              <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:10, flexWrap:"wrap" }}>
                <h3 style={{ fontSize:16.5, fontWeight:700 }}>{u.name}</h3>
                <RoleBadge type={u.type} />
              </div>
              <div style={{ fontSize:13, color:"var(--ink-3)", marginTop:3 }}>{u.email}</div>
              {u.bio && <p style={{ fontSize:13.5, color:"var(--ink-2)", marginTop:10, lineHeight:1.45, display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{u.bio}</p>}
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginTop:12, paddingTop:12, borderTop:"1px solid var(--border)" }}>
                <span style={{ fontSize:12.5, color:"var(--ink-3)" }}>Reg. {u.reg}</span>
                <div style={{ display:"flex", gap:8 }}>
                  <Btn variant="ghost" icon="eye" size="sm" onClick={()=>onOpenProfile(u.id)}>Profilo</Btn>
                  <Btn variant="soft" icon="mail" size="sm">Contatta</Btn>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------- Admin ---------- */
function AdminScreen({ mobile }) {
  const [ops, setOps] = useStateOp([{ id:"o1", name:"Operatore Test", email:"operatore@incrowd.com", initials:"OT" }]);
  const [form, setForm] = useStateOp({ nome:"", cognome:"", email:"", pw:"" });
  const set = (k,v)=>setForm(f=>({...f,[k]:v}));
  const add = () => {
    if(!form.nome||!form.email) return;
    setOps(l=>[...l,{ id:"o"+Date.now(), name:`${form.nome} ${form.cognome}`.trim(), email:form.email, initials:(form.nome[0]||"")+(form.cognome[0]||"") }]);
    setForm({ nome:"", cognome:"", email:"", pw:"" });
  };

  return (
    <div style={{ maxWidth:1000, margin:"0 auto", padding:"clamp(16px,3vw,28px) clamp(14px,4vw,28px) 80px", display:"flex", flexDirection:"column", gap:"var(--s-5)" }}>
      <div style={{ position:"relative", overflow:"hidden", borderRadius:"var(--r-lg)",
        background:"linear-gradient(110deg, var(--brand) 0%, var(--brand-700) 55%, #3a2a24 100%)", color:"#fff", padding:mobile?"24px 22px":"32px 36px" }}>
        <div style={{ position:"absolute", right:-30, top:-50, width:200, height:200, borderRadius:"50%", background:"rgba(255,255,255,.12)" }} />
        <div style={{ display:"flex", alignItems:"center", gap:14, position:"relative" }}>
          <div style={{ width:50, height:50, borderRadius:15, background:"rgba(255,255,255,.2)", display:"grid", placeItems:"center" }}><Icon name="shield" size={26} stroke={2}/></div>
          <div>
            <h1 style={{ fontSize:mobile?24:30, fontWeight:800 }}>Gestione Operatori</h1>
            <p style={{ color:"rgba(255,255,255,.85)", marginTop:4 }}>Amministra gli operatori del sistema</p>
          </div>
          <span style={{ flex:1 }} />
          {!mobile && <div style={{ textAlign:"center" }}>
            <div style={{ fontFamily:"var(--font-display)", fontWeight:800, fontSize:36 }}>{ops.length}</div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,.85)", fontWeight:600 }}>Operatori attivi</div>
          </div>}
        </div>
      </div>

      <Card pad="clamp(20px,3vw,28px)">
        <h2 style={{ fontSize:20, fontWeight:700, marginBottom:18 }}>Aggiungi nuovo operatore</h2>
        <div style={{ display:"grid", gap:16, gridTemplateColumns: mobile?"1fr":"1fr 1fr" }}>
          <div><label className="ic-label">Nome *</label><input className="ic-input" value={form.nome} onChange={e=>set("nome",e.target.value)} placeholder="Nome operatore" /></div>
          <div><label className="ic-label">Cognome *</label><input className="ic-input" value={form.cognome} onChange={e=>set("cognome",e.target.value)} placeholder="Cognome operatore" /></div>
          <div><label className="ic-label">Email *</label><input className="ic-input" value={form.email} onChange={e=>set("email",e.target.value)} placeholder="email@esempio.com" /></div>
          <div><label className="ic-label">Password *</label><input className="ic-input" type="password" value={form.pw} onChange={e=>set("pw",e.target.value)} placeholder="Password sicura" /></div>
        </div>
        <div style={{ marginTop:18 }}><Btn icon="plus" onClick={add} disabled={!form.nome||!form.email}>Aggiungi operatore</Btn></div>
      </Card>

      <div>
        <SectionTitle>Operatori attivi</SectionTitle>
        <div style={{ display:"grid", gap:"var(--s-4)", gridTemplateColumns: mobile?"1fr":"repeat(auto-fill,minmax(320px,1fr))" }}>
          {ops.map(o => (
            <Card key={o.id} pad="16px" style={{ display:"flex", alignItems:"center", gap:14 }}>
              <div style={{ width:50, height:50, borderRadius:"50%", background:"var(--brand)", color:"#fff", display:"grid", placeItems:"center", fontFamily:"var(--font-display)", fontWeight:800, fontSize:18 }}>{o.initials}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight:700, fontSize:15.5 }}>{o.name}</div>
                <div style={{ fontSize:13, color:"var(--ink-3)" }}>{o.email}</div>
                <Badge color="var(--ink-2)" bg="var(--surface-3)" icon="tool" style={{ marginTop:6 }}>Operatore</Badge>
              </div>
              <Btn variant="danger" icon="trash" size="sm" onClick={()=>setOps(l=>l.filter(x=>x.id!==o.id))}>Rimuovi</Btn>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { OperatorScreen, AdminScreen });
